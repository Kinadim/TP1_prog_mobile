package com.example.tp1_ex9;

public class Evenement {
    private String titre;
    private String date;
    private String heure_debut;
    private String heure_fin;
    private String description;

    // Constructeur
    public Evenement(String titre, String date, String heure_debut, String heure_fin, String description) {
        this.titre = titre;
        this.date = date;
        this.heure_debut = heure_debut;
        this.heure_fin = heure_fin;
        this.description = description;
    }

    // Getters
    public String getTitre() {
        return titre;
    }

    public String getDate() {
        return date;
    }

    public String getHeure_debut() {
        return heure_debut;
    }

    public String getHeure_fin() {
        return heure_fin;
    }

    public String getDescription() {
        return description;
    }

    // Setters
    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setHeure_debut(String heure_debut){
        this.heure_debut = heure_debut;
    }

    public void setHeure_fin(String heure_fin){
        this.heure_fin = heure_fin;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    // Méthode pour afficher l'événement
    @Override
    public String toString() {
        return "Événement{" +
                "titre='" + titre + '\'' +
                ", date='" + date + '\'' +
                ", description='" + description + '\'' +
                '}';
    }


}
