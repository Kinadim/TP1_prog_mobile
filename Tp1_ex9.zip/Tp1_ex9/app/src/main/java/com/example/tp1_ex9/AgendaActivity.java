package com.example.tp1_ex9;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;

import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

public class AgendaActivity extends Activity {

    List<Evenement> evenementList = new ArrayList<>();
    String selectedDate;
    CalendarView calendarView;
    RecyclerView recyclerView;
    EvenementAdapter evenementAdapter;
    List<Evenement> evenementDuJourList = new ArrayList<>();


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepagelayout);

        Button btnEvent = findViewById(R.id.btn_add_event);
        calendarView = findViewById(R.id.calendarView);
        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        View.OnClickListener itemClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int position = recyclerView.getChildAdapterPosition(view);
                Evenement evenement = evenementDuJourList.get(position);
                showInfoDialog(evenement);
            }
        };


        evenementAdapter = new EvenementAdapter(evenementDuJourList, itemClickListener);
        recyclerView.setAdapter(evenementAdapter);

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getAdapterPosition();
                Evenement eventToRemove = evenementDuJourList.get(position);
                evenementList.remove(eventToRemove);
                evenementDuJourList.remove(position);
                evenementAdapter.notifyItemRemoved(position);
            }

        });

        itemTouchHelper.attachToRecyclerView(recyclerView);


        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                mettreAJourEvenements();
            }
        });

        btnEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showEvenDialog();
            }
        });

        List<Evenement> savedEvents = getEventsFromSharedPreferences();
        if (savedEvents != null) {
            evenementList.addAll(savedEvents);
            mettreAJourEvenements();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveEventsToSharedPreferences(evenementList);
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Evenement> savedEvents = getEventsFromSharedPreferences();
        if (savedEvents != null) {
            evenementList = savedEvents;
            mettreAJourEvenements();
        }
    }

    private void saveEventsToSharedPreferences(List<Evenement> evenementList) {
        SharedPreferences sharedPreferences = getSharedPreferences("AgendaPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(evenementList);
        editor.putString("events", json);
        editor.apply();
    }


    private List<Evenement> getEventsFromSharedPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences("AgendaPrefs", MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("events", null);
        if (json == null) {
            return new ArrayList<>();
        }
        Type type = new TypeToken<List<Evenement>>() {}.getType();
        return gson.fromJson(json, type);
    }

    private void mettreAJourEvenements() {
        evenementDuJourList.clear();
        for (Evenement event : evenementList) {
            if (Objects.equals(event.getDate(), selectedDate)) {
                evenementDuJourList.add(event);
            }
        }
        evenementDuJourList.sort((event1, event2) -> event1.getHeure_debut().compareTo(event2.getHeure_debut()));

        evenementAdapter.notifyDataSetChanged();
    }

    @SuppressLint("SetTextI18n")
    private void showInfoDialog(Evenement event){
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.dialog_layout);

            TextView tvTitre = dialog.findViewById(R.id.tv_titre);
            TextView tvDescription = dialog.findViewById(R.id.tv_description);
            TextView tvDate = dialog.findViewById(R.id.tv_date);
            TextView tvHeure_debut = dialog.findViewById(R.id.tv_heure_debut);
            TextView tvHeure_fin = dialog.findViewById(R.id.tv_heure_fin);

            tvTitre.setText("Titre :"+event.getTitre());
            tvDescription.setText("Description :"+ event.getDescription());
            tvDate.setText("Date :" + event.getDate());
            tvHeure_debut.setText("Heure début :" + event.getHeure_debut());
            tvHeure_fin.setText("Heure fin :" + event.getHeure_fin());

        dialog.show();
    }

    private void showEvenDialog(){
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.event_layout);

        Button btnValide = dialog.findViewById(R.id.btn_valider);
        Button btnAnnule = dialog.findViewById(R.id.btn_annuler);

        EditText editTitre = dialog.findViewById(R.id.edit_titre);
        EditText editDescription = dialog.findViewById(R.id.edit_description);
        EditText editDate = dialog.findViewById(R.id.edit_date);
        EditText editHeure_debut = dialog.findViewById(R.id.edit_heure_debut);
        EditText editHeure_fin = dialog.findViewById(R.id.edit_heure_fin);
        editDate.setText(selectedDate);

       editDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(dialog.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDay) {
                        String selectedDate = selectedDay + "/" + (selectedMonth + 1) + "/" + selectedYear;
                        editDate.setText(selectedDate);
                    }
                }, year, month, day);

                datePickerDialog.show();
            }
        });

        editHeure_debut.setText("08:00");
        editHeure_debut.setOnClickListener(v -> showTimePickerDialog(dialog, editHeure_debut));

        // Sélection de l'heure de fin
        editHeure_fin.setText("09:00");
        editHeure_fin.setOnClickListener(v -> showTimePickerDialog(dialog, editHeure_fin));


        btnAnnule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        btnValide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String titre = editTitre.getText().toString();
                String description = editDescription.getText().toString();
                String date = editDate.getText().toString();
                String heure_debut = editHeure_debut.getText().toString();
                String heure_fin = editHeure_fin.getText().toString();

                if(titre.isEmpty()){
                    Toast.makeText(dialog.getContext(), "L'évènement doit avoir un titre", Toast.LENGTH_LONG).show();
                    return;
                }
                if (!isTimeValid(heure_debut, heure_fin)) {
                    Toast.makeText(dialog.getContext(), "L'heure de fin doit être après l'heure de début", Toast.LENGTH_LONG).show();
                    return;
                }
                Evenement evenement = new Evenement(titre, date,heure_debut,heure_fin,  description);
                evenementList.add(evenement);

                mettreAJourEvenements();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void showTimePickerDialog(Dialog dialog, EditText editText) {
        Calendar calendar = Calendar.getInstance();
        int heure = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(dialog.getContext(),
                (view, selectedHeure, selectedMinute) -> {
                    String selectedHeureMinute = String.format("%02d:%02d", selectedHeure, selectedMinute);
                    editText.setText(selectedHeureMinute);
                }, heure, minute, true);

        timePickerDialog.show();
    }

    private boolean isTimeValid(String heureDebut, String heureFin) {
        String[] startTimeParts = heureDebut.split(":");
        String[] endTimeParts = heureFin.split(":");

        int startHour = Integer.parseInt(startTimeParts[0]);
        int startMinute = Integer.parseInt(startTimeParts[1]);
        int endHour = Integer.parseInt(endTimeParts[0]);
        int endMinute = Integer.parseInt(endTimeParts[1]);

        return (endHour > startHour) || (endHour == startHour && endMinute > startMinute);
    }
}