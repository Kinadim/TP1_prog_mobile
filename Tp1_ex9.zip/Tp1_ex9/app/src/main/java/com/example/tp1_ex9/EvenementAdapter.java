package com.example.tp1_ex9;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EvenementAdapter extends RecyclerView.Adapter<EvenementAdapter.EvenementViewHolder> {

    private List<Evenement> evenementList;
    private View.OnClickListener onClickListener;  // Ajout du listener

    // Constructeur avec listener
    public EvenementAdapter(List<Evenement> evenementList, View.OnClickListener onClickListener) {
        this.evenementList = evenementList;
        this.onClickListener = onClickListener;
    }

    @NonNull
    @Override
    public EvenementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new EvenementViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EvenementViewHolder holder, int position) {
        Evenement evenement = evenementList.get(position);
        holder.tvTitre.setText(evenement.getTitre());
        holder.tvDate.setText(evenement.getDate());
        holder.tv_heure_debut.setText(evenement.getHeure_debut());
        holder.tv_heure_fin.setText(evenement.getHeure_fin());

        // Attache le listener de clic à chaque item
        holder.itemView.setOnClickListener(onClickListener);
    }

    @Override
    public int getItemCount() {
        return evenementList.size();
    }

    // ViewHolder interne
    public static class EvenementViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitre, tvDate, tv_heure_debut, tv_heure_fin, tvDescription;

        public EvenementViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitre = itemView.findViewById(R.id.tv_titre);
            tvDate = itemView.findViewById(R.id.tv_date);
            tv_heure_debut = itemView.findViewById(R.id.tv_heure_debut);
            tv_heure_fin = itemView.findViewById(R.id.tv_heure_fin);
            tvDescription = itemView.findViewById(R.id.tv_description);
        }
    }
}
