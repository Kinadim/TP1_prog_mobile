package com.example.tp1_prog_mobile_app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class PersonneActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.personnelayout);
        Intent intent = getIntent();
        TextView text_prenom = findViewById(R.id.txt_prenom);
        text_prenom.setText(intent.getStringExtra("prenom"));
        TextView text_nom = findViewById(R.id.txt_nom);
        text_nom.setText(intent.getStringExtra("nom"));

        TextView text_age = findViewById(R.id.txt_age);
        text_age.setText(intent.getStringExtra("age"));

        TextView text_dom = findViewById(R.id.txt_domaine);
        text_dom.setText(intent.getStringExtra("domaine"));

        TextView text_tel = findViewById(R.id.txt_phone);
        text_tel.setText(intent.getStringExtra("tel"));

        Button annuler = findViewById(R.id.btn_annuler);
        Button ok = findViewById(R.id.btn_enregistrer);

        annuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.basiclayout);
                Intent intent = new Intent (PersonneActivity.this, HelloWordActivity.class);
                startActivity(intent);
            }
        });

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.personnelayout);
                Intent intent = new Intent (PersonneActivity.this, AppellerActivity.class);
                intent.putExtra("tel",text_tel.getText().toString());
                startActivity(intent);
            }
        });
    }
}
