package com.example.tp1_prog_mobile_app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;

public class HelloWordActivity extends Activity {
    EditText edit_nom, edit_prenom, edit_age, edit_dom,edit_tel;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.basiclayout);
        Button valide = findViewById(R.id.btn_valider);
        edit_nom = findViewById(R.id.edit_nom);
        edit_prenom = findViewById(R.id.edit_prenom);
        edit_age = findViewById(R.id.edit_age);
        edit_dom = findViewById(R.id.edit_domaine);
        edit_tel = findViewById(R.id.edit_phone);



       //faire comme valide pour edit
        valide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showEvenDialog();
            }
        });
    }

    private void showEvenDialog() {
        Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_layout);

        Button btnValide = dialog.findViewById(R.id.btn_valider);
        Button btnAnnule = dialog.findViewById(R.id.btn_annuler);

        btnAnnule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });

        btnValide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.personnelayout);
                Intent intent = new Intent (HelloWordActivity.this, PersonneActivity.class);
                intent.putExtra("nom",edit_nom.getText().toString());
                intent.putExtra("prenom",edit_prenom.getText().toString());
                intent.putExtra("age",edit_age.getText().toString());
                intent.putExtra("domaine",edit_dom.getText().toString());
                intent.putExtra("tel",edit_tel.getText().toString());
                startActivity(intent);
                dialog.dismiss();
            }
        });

        dialog.show();
    }

}
