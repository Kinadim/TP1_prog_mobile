package com.example.tp1_ex8;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HoraireAdapter extends RecyclerView.Adapter<HoraireAdapter.HoraireViewHolder> {

    private List<Horaire> horairesList;


    public HoraireAdapter(List<Horaire> horairesList) {
        this.horairesList = horairesList;
    }

    @NonNull
    @Override
    public HoraireViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_layout, parent, false);
        return new HoraireViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull HoraireViewHolder holder, int position) {

        Horaire horaire = horairesList.get(position);

        holder.txtNumeroTrain.setText("Train N° " + horaire.getNumeroTrain());
        holder.txtHeureDepart.setText("Départ : " + horaire.getHeureDepart());
        holder.txtHeureArrivee.setText("Arrivée : " + horaire.getHeureArrivee());
        holder.txtDuree.setText("Durée : " + horaire.getDuree());
        holder.txtTypeDeTrain.setText("Type de train : "+ horaire.getType_de_train());

        holder.imgTrain.setImageResource(R.drawable.ic_train_foreground);
    }

    @Override
    public int getItemCount() {
        return horairesList.size();
    }

    public static class HoraireViewHolder extends RecyclerView.ViewHolder {

        TextView txtNumeroTrain, txtHeureDepart, txtHeureArrivee, txtDuree, txtTypeDeTrain;
        ImageView imgTrain;

        public HoraireViewHolder(View itemView) {
            super(itemView);
            txtNumeroTrain = itemView.findViewById(R.id.txt_numero_train);
            txtHeureDepart = itemView.findViewById(R.id.txt_heure_depart);
            txtHeureArrivee = itemView.findViewById(R.id.txt_heure_arrivee);
            txtDuree = itemView.findViewById(R.id.txt_duree);
            txtTypeDeTrain = itemView.findViewById(R.id.txt_commercial_mode);
            imgTrain = itemView.findViewById(R.id.img_train);
        }
    }
}
