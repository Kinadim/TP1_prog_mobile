package com.example.tp1_ex8;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

public class HomeActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homelayout);

        EditText editDepart = findViewById(R.id.edit_depart);
        EditText editArrivee = findViewById(R.id.edit_arrivee);
        Button btnRechercher = findViewById(R.id.btn_rechercher);

        btnRechercher.setOnClickListener(view -> {
            String depart = editDepart.getText().toString();
            String arrivee = editArrivee.getText().toString();

            if (depart.isEmpty() || arrivee.isEmpty()) {
                Toast.makeText(HomeActivity.this, "Remplissez les champs", Toast.LENGTH_SHORT).show();
                return;
            }

            // Requête API
            SNCFClient.rechercherItineraire(depart, arrivee, new SNCFClient.ApiResponseListener() {
                SimpleDateFormat inputFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
                SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm");
                @Override
                public void onSuccess(JSONObject response) {
                    runOnUiThread(() -> {
                        Toast.makeText(HomeActivity.this, "Réponse reçue", Toast.LENGTH_LONG).show();


                        List<Horaire> horairesList = new ArrayList<>();
                        try {
                            JSONArray journeys = response.getJSONArray("journeys");

                            for (int i = 0; i < journeys.length(); i++) {
                                JSONObject journey = journeys.getJSONObject(i);
                                String heureDepart = journey.getString("departure_date_time");
                                Date date_depart = inputFormat.parse(heureDepart);
                                heureDepart = outputFormat.format(date_depart);
                                String heureArrivee = journey.getString("arrival_date_time");
                                Date date_arrive = inputFormat.parse(heureArrivee);
                                heureArrivee = outputFormat.format(date_arrive);
                                String duree = journey.getString("duration");

                                JSONArray sections = journey.getJSONArray("sections");
                                String numeroTrain = "";
                                String typeDeTrain = "";


                                for (int j = 0; j < sections.length(); j++) {
                                    JSONObject section = sections.getJSONObject(j);

                                    if (section.length() == 16) {
                                        numeroTrain = section.getJSONObject("display_informations").getString("headsign");
                                        typeDeTrain = section.getJSONObject("display_informations").getString("commercial_mode");
                                    }
                                }


                                horairesList.add(new Horaire(numeroTrain, heureDepart, heureArrivee, duree, typeDeTrain));


                            }


                            RecyclerView recyclerView = findViewById(R.id.recyclerView);
                            recyclerView.setLayoutManager(new LinearLayoutManager(HomeActivity.this));

                            HoraireAdapter adapter = new HoraireAdapter(horairesList);
                            recyclerView.setAdapter(adapter);
                        } catch (Exception e) {
                            e.printStackTrace();
                            Toast.makeText(HomeActivity.this, "Erreur lors du traitement des données", Toast.LENGTH_LONG).show();
                        }
                    });
                }


                @Override
                public void onError(String error) {
                    runOnUiThread(() -> {
                        Toast.makeText(HomeActivity.this, error, Toast.LENGTH_LONG).show();
                    });
                }
            });

        });
    }
}
