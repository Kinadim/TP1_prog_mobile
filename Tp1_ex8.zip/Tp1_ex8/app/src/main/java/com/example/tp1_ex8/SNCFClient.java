package com.example.tp1_ex8;
import okhttp3.*;
import org.json.JSONObject;
import java.io.IOException;
import android.util.Log;

public class SNCFClient {
    private static final String API_KEY = "0503def7-c65a-425b-be42-261595735c89";
    private static final String BASE_URL = "https://api.sncf.com/v1/coverage/sncf/journeys";

    public interface ApiResponseListener {
        void onSuccess(JSONObject response);
        void onError(String error);
    }

    public static void rechercherItineraire(String depart, String arrivee, ApiResponseListener listener) {
        OkHttpClient client = new OkHttpClient();

        rechercherCodeVille(depart, new ApiResponseListener() {
            @Override
            public void onSuccess(JSONObject response) {
                String departCode = extraireCodeVille(response);

                rechercherCodeVille(arrivee, new ApiResponseListener() {
                    @Override
                    public void onSuccess(JSONObject response) {
                        String arriveeCode = extraireCodeVille(response);

                        HttpUrl url = HttpUrl.parse(BASE_URL).newBuilder()
                                .addQueryParameter("from", departCode)
                                .addQueryParameter("to", arriveeCode)
                                .addQueryParameter("count", "10")
                                .build();

                        Log.d("SNCFClient", "URL générée : " + url.toString());

                        Request request = new Request.Builder()
                                .url(url)
                                .addHeader("Authorization", API_KEY)
                                .build();

                        client.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(Call call, IOException e) {
                                listener.onError("Erreur réseau : " + e.getMessage());
                            }

                            @Override
                            public void onResponse(Call call, Response response) throws IOException {
                                if (response.isSuccessful()) {
                                    try {
                                        JSONObject jsonResponse = new JSONObject(response.body().string());
                                        listener.onSuccess(jsonResponse);
                                    } catch (Exception e) {
                                        listener.onError("Erreur de parsing JSON : " + e.getMessage());
                                    }
                                } else {
                                    String errorMessage = "Erreur API : " + response.message();
                                    listener.onError(errorMessage);
                                }
                            }
                        });
                    }

                    @Override
                    public void onError(String error) {
                        listener.onError("Erreur pour la ville d'arrivée : " + error);
                    }
                });
            }

            @Override
            public void onError(String error) {
                listener.onError("Erreur pour la ville de départ : " + error);
            }
        });
    }

    private static String extraireCodeVille(JSONObject response) {
        return response.optJSONArray("places").optJSONObject(0).optString("id");
    }

    public static void rechercherCodeVille(String ville, ApiResponseListener listener) {
        OkHttpClient client = new OkHttpClient();

        // URL de recherche de villes
        HttpUrl url = HttpUrl.parse("https://api.sncf.com/v1/coverage/sncf/places").newBuilder()
                .addQueryParameter("q", ville)  // Recherche par nom de la ville
                .build();

        Request request = new Request.Builder()
                .url(url)
                .addHeader("Authorization", API_KEY)
                .build();

        // Exécution de la requête
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                listener.onError("Erreur réseau : " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response.body().string());
                        listener.onSuccess(jsonResponse);
                    } catch (Exception e) {
                        listener.onError("Erreur de parsing JSON : " + e.getMessage());
                    }
                } else {
                    listener.onError("Erreur API : " + response.message());
                }
            }
        });
    }


}
