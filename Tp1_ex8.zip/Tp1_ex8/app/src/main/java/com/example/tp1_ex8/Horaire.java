package com.example.tp1_ex8;

import android.annotation.SuppressLint;

public class Horaire {
    private String numeroTrain;
    private String heureDepart;
    private String heureArrivee;
    private String duree;
    private String type_de_train;

    public Horaire(String numeroTrain, String heureDepart, String heureArrivee, String duree, String type_de_train) {
        this.numeroTrain = numeroTrain;
        this.heureDepart = heureDepart;
        this.heureArrivee = heureArrivee;
        this.duree = convertSecondsToTime(duree);
        this.type_de_train = type_de_train;
    }

    public String getNumeroTrain() {
        return numeroTrain;
    }

    public String getHeureDepart() {
        return heureDepart;
    }

    public String getHeureArrivee() {
        return heureArrivee;
    }

    public String getDuree() {
        return duree;
    }

    public String getType_de_train() {
        return type_de_train;
    }

    @SuppressLint("DefaultLocale")
    public String convertSecondsToTime(String secondsStr) {
        try {
            int totalSeconds = Integer.parseInt(secondsStr);
            int hours = totalSeconds / 3600;
            int minutes = (totalSeconds % 3600) / 60;
            return String.format("%02dh%02d", hours, minutes);
        } catch (NumberFormatException e) {
            return "Format invalide";
        }
    }
}

